Michael J Adami
656717220
Proj 1

It should work as expected, no bugs that I had found. I tried it with the autograder and it gave me a 26.

Thanks, Adami