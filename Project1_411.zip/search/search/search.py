# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

#EDITED: MICHAEL ADMAI
"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
from util import PriorityQueue
from util import Stack
from util import Queue


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).
    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state
        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state
        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take
         
        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()

def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

class FixedPQFunction(PriorityQueue):
    #SELF DEFINED PQUEUE
    def  __init__(self, problem, priorityFunction):
        self.priorityFunction = priorityFunction  
        PriorityQueue.__init__(self)    
        self.problem = problem
        
    def push(self, item, heuristic):
        PriorityQueue.push(self, item, self.priorityFunction(self.problem,item,heuristic))#Push items
        
def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.
    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.
    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:
    """

    path = [] # Every nodes keeps it's path from the starting state
    visitedNodes = [] # Visited Nodes  
    stack = Stack()

    if problem.isGoalState(problem.getStartState()):#Check if we already reached the end
        return []

    stack.push((problem.getStartState(),[]))#Start off empty and then continue
    while(True):
        if stack.isEmpty():
            return []

        xy,path = stack.pop() # Take position and path
        visitedNodes.append(xy)

        if problem.isGoalState(xy): #If we go to goal
            return path

        successor = problem.getSuccessors(xy)
        
        if successor: #Start adding to path
            for i in successor:
                if i[0] not in visitedNodes:
                    newPath = path + [i[1]] 
                    stack.push((i[0],newPath))

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    
    path = [] # Every node keeps it's path from the starting state
    visitedNodes = [] # Visited Nodes
    queue = Queue()
    
    if problem.isGoalState(problem.getStartState()): #We reached the goal in beginning
        return []

    queue.push((problem.getStartState(),[]))#We need to start the queue
    
    while(True):
        if queue.isEmpty(): #No solution
            return []

        xy,path = queue.pop() # Take position and path
        visitedNodes.append(xy)

        if problem.isGoalState(xy): #We reached the goal
            return path

        successor = problem.getSuccessors(xy) #successor of curr
        if successor:
            for i in successor:
                if i[0] not in visitedNodes and i[0] not in (state[0] for state in queue.list):
                    newPath = path + [i[1]]
                    queue.push((i[0],newPath))

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    
    path = [] # Every state keeps it's path from the starting state   
    visitedNodes = [] # Visited Nodes
    pqueue = PriorityQueue()
    
    if problem.isGoalState(problem.getStartState()): #When we start are we there?
        return []

    pqueue.push((problem.getStartState(),[]),0) #Start at the beginning.

    while(True):
        if pqueue.isEmpty(): #No solution
            return []
        xy,path = pqueue.pop() # Get the position
        visitedNodes.append(xy) #Put inside of the visited, so we don't go back
        if problem.isGoalState(xy): #We reached the goal
            return path #Return correct path

        successors = problem.getSuccessors(xy)#Get the node before

        if successors: #start off
            for i in successors:
                if i[0] not in visitedNodes and (i[0] not in (state[2][0] for state in pqueue.heap)):
                    newPath = path + [i[1]]
                    totcost = problem.getCostOfActions(newPath)

                    pqueue.push((i[0],newPath),totcost)

                
                elif i[0] not in visitedNodes and (i[0] in (state[2][0] for state in pqueue.heap)): #make sure we are not going back
                    for state in pqueue.heap:
                        if state[2][0] == i[0]:
                            originalCost = problem.getCostOfActions(state[2][1])

                    newCost = problem.getCostOfActions(path + [i[1]])

                    # State is cheaper with his hew father -> update and fix parent #
                    if originalCost > newCost:
                        newPath = path + [i[1]]
                        pqueue.update((i[0],newPath),newCost)

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def f(problem,state,heuristic):
    return problem.getCostOfActions(state[1]) + heuristic(state[0],problem)

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    path = [] # Every nodes keeps it's path from the starting state
    visitedNodes = [] # Visited nodes
    pqueue = FixedPQFunction(problem,f)

    if problem.isGoalState(problem.getStartState()):#If we are already in the goal 
        return []

    element = (problem.getStartState(),[])#Starting off

    pqueue.push(element,heuristic)

    while(True):
        if pqueue.isEmpty(): #No solution
            return []

        xy,path = pqueue.pop() # Get the path

        if xy in visitedNodes: #Already added
            continue

        visitedNodes.append(xy) #Else add
        
        if problem.isGoalState(xy):#We reached the goal
            return path

        successor = problem.getSuccessors(xy)#State before the current

        if successor: #Add to the path
            for i in successor:
                if i[0] not in visitedNodes:

                    newPath = path + [i[1]] # Fix new path
                    element = (i[0],newPath)
                    pqueue.push(element,heuristic)

bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
