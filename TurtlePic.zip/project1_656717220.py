#Project: Project 1
#UIN: 656717220
#URL to repl.it: https://repl.it/@madami5/RealFaithfulSemicolon
#For this project, I received no help.
import turtle

def main():
 tetris()

t1=turtle.Turtle()
screen=t1.getscreen() 
screen.tracer(10) 
screen.setup(600,800) #The screen size

def draw_polygon(sides,length,x,y,color): # function for the polygon
  t1.penup()
  t1.goto(x,y)
  t1.pendown()
  t1.color(color)
  t1.begin_fill()
  for i in range(sides):
    t1.forward(length)
    t1.right(360/sides)
  t1.end_fill() 
  t1.penup()
  
def draw_circle(radius,x,y,color):#function for the circles
  t1.penup()
  t1.goto(x,y)
  t1.pendown()
  t1.color(color)
  t1.begin_fill()
  t1.circle(radius)
  t1.end_fill()
  
def draw_rectangle(length,width,color,x,y):
  t1.penup()
  t1.goto(x,y)
  t1.pendown()
  t1.color(color)
  t1.begin_fill()
  t1.setheading(90)
  for i in range(4):
    t1.forward(length)
    t1.right(90)
    t1.forward(width)
  t1.end_fill()
def tetris():
  draw_polygon(4,500,-300,100,"black")
  draw_rectangle(15,50,"light green",-15,30)
  draw_rectangle(15,50,"red",-200,-350)
  draw_rectangle(15,50,"red",-135,-350)
  draw_rectangle(15,50,"yellow",-300,-350)
  draw_rectangle(15,50,"yellow",-265,-350)
  draw_rectangle(15,50,"yellow",-300,-285)
  draw_circle(50,-200,20,"orange")
  draw_rectangle(15,50,"blue",80,-350)
  draw_rectangle(15,50,"blue",135,-350)
  draw_rectangle(15,50,"light green",-15,-20)
  draw_rectangle(15,50,"light green",30,-20)
  draw_rectangle(15,50,"light green",-60,-20)
  draw_polygon(3,40,-260,0,"red")
main()