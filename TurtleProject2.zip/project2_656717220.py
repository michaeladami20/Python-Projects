#project: Project 2
#UIN:656717220
#URL to repl.it:https://repl.it/@madami5/LumpyWiseSymbols
import turtle
import random
import math
t= turtle.Turtle()#ALL the turtles I used during the project
t2=turtle.Turtle()
t3=turtle.Turtle()
t4=turtle.Turtle()
t5=turtle.Turtle()
t6=turtle.Turtle()
t9=turtle.Turtle()
t10=turtle.Turtle()
screen = turtle.Screen()
# define some functions

def move_up():
  t.setheading(90)
  t.forward(10)


def move_down():
  t.setheading(270)
  t.forward(10)

screen = t.getscreen()
screen.setup(500,500)
screen.bgcolor("black")
t.tracer(0)

villain = {  #Dictionaries of the game
  "x" : -200,
  "y" : 40,
  "radius": 25,
  "color" :"blue",
  "speed" : 20,
  "lives":3,
  "score":0
}

money1= {
  "points": 100,
  "x": 200,
  "y": random.randint(-200,200),
  "speed":7,
  "color":"yellow",
  "radius":15
}
money2= {
  "points": 100,
  "x": 200,
  "y": random.randint(-200,200),
  "speed":7,
  "color":"yellow",
  "radius":15
}
killer3={
"kill": 1,
"y":random.randint(-200,200),
"x":260,
"speed":7,
"color":"red",
"radius":20
}
killer4={
"kill": 1,
"y":random.randint(-200,200),
"x":260,
"speed":7,
"color":"red",
"radius":20
}
killer5={
"kill": 1,
"y":random.randint(-200,200),
"x":260,
"speed":6,
"color":"red",
"radius":20
}

def draw_villain():#Draw The stuff
  ''' draw the villain, using its properties'''
  t.penup()
  t.goto(villain["x"], villain["y"])
  t.pendown()
  t.color(villain["color"])
  t.circle(villain["radius"])
  t.fill(villain["color"])
  t.hideturtle()
def draw_money1():
  t2.penup()
  t2.goto(money1["x"],money1["y"])
  t2.pendown()
  t2.color(money1["color"])
  t2.circle(money1["radius"])
  t2.fill(money1["radius"])
  t2.hideturtle()
def draw_money2():
  t6.penup()
  t6.goto(money2["x"],money2["y"])
  t6.pendown()
  t6.color(money2["color"])
  t6.circle(money2["radius"])
  t6.fill(money2["radius"])
  t6.hideturtle()
def draw_killer3():
  t3.penup()
  t3.goto(killer3["x"],killer3["y"])
  t3.pendown()
  t3.color(killer3["color"])
  t3.circle(killer3["radius"])
  t3.fill(killer3["color"])
  t3.hideturtle() 
  killer3["x"]-=killer3["speed"]
def draw_killer4():
  t4.penup()
  t4.goto(killer4["x"],killer4["y"])
  t4.pendown()
  t4.color(killer4["color"])
  t4.circle(killer4["radius"])
  t4.fill(killer4["color"])
  t4.hideturtle()
def draw_killer5():
  t5.penup()
  t5.goto(killer5["x"],killer5["y"])
  t5.pendown()
  t5.color(killer5["color"])
  t5.circle(killer5["radius"])
  t5.fill(killer5["color"])
  t5.hideturtle()
  killer5["x"]-=killer5["speed"]
def colliding (char_1, char_2):
  dx=char_1["x"]-char_2["x"]
  dy=char_1["y"]-char_2["y"]
  distance= math.sqrt(dx*dx+dy*dy)
  if (distance<char_1["radius"]+char_2["radius"]):
    collision_detected=True
  else:
    collision_detected = False;

  return collision_detected
def score_keep():#Score of the game!
  t10.clear() 
  t10.penup()
  t10.goto(100,170)
  t10.pendown()
  t10.color("green")
  t10.write("score is: ",villain["score"], font=("Arial", 14, "normal","bold"))
  t10.penup()
  t10.hideturtle()
  t10.update()
  return
while villain["lives"]>0: #Continous loop
  score_keep()
  t.clear()
  draw_villain()
  t.update()
  def move_up(): 
    villain["y"]+=villain["speed"]
  def move_down():
    villain["y"]-=villain["speed"]
  screen.onkey(move_up, "up")
  screen.onkey(move_down,"down")
  screen.listen()
  if (280<villain["y"]):
    villain["y"]=-260
  elif (villain["y"]<-280):
    villain["y"]=260

  if (colliding(villain,money1)):
    villain["score"]+=money1["points"] 

  t2.clear()
  draw_money1()
  t2.update()
  if (villain["score"]>100):
    t3.clear()
    draw_killer3()  
    killer3["x"]-=killer3["speed"]
    t3.update()  
    if (colliding(villain,killer3)):
      villain["lives"]-=killer3["kill"]
  if (villain["score"]>100):
    t4.clear()
    draw_killer4()  
    killer4["x"]-=killer4["speed"]
    t4.update()  
    if (colliding(villain,killer4)):
      villain["lives"]-=killer4["kill"]
  
  if(villain["score"]>1000):
    t5.clear()
    draw_killer5()
    t5.update()
    if (colliding(villain,killer5)):
      villain["lives"]-=killer5["kill"]
  if(villain["score"]>600):
    t6.clear()
    draw_money2()
    t6.update()
  if (colliding(villain,money2)):#Add up points
    villain["score"]+=money2["points"]
  if(villain["score"]>300):
    villain["radius"]=40
  if(money1["x"]<=-300 or colliding(villain,money1)):
    money1["y"]=random.randint(-200,200)
    money1["x"]=300
  money1["x"]-=money1["speed"]
  if(money2["x"]<=-300 or colliding(villain,money2)):
    money2["y"]=random.randint(-200,200)
    money2["x"]=300
  money2["x"]-=money2["speed"]
  if(killer3["x"]<=-300 or colliding(villain, killer3)):
    killer3["y"]=random.randint(-200,200)
    killer3["x"]=300
  if(killer4["x"]<=-300 or colliding(villain, killer4)):
      killer4["y"]=random.randint(-200,200)
      killer4["x"]=300
  if(killer5["x"]<=-300 or colliding(villain, killer5)):
    killer5["y"]=random.randint(-200,200)
    killer5["x"]=300
  if (villain["lives"]==3):#Messages
    t9.penup()
    t9.goto(100,200)
    t9.pendown()
    t9.color("green")
    t9.write("Lives are 3", font=("Arial", 14, "normal","bold"))
    t9.penup()
    t9.hideturtle()
  elif(villain["lives"]==2):

    t9.clear()   
    t9.penup()
    t9.goto(100,200)
    t9.pendown()
    t9.color("yellow")
    t9.write("Lives are 2", font=("Arial", 14, "normal","bold"))
    t9.penup()
    t9.hideturtle()
  else:
    t9.clear()
    t9.penup()
    t9.goto(100,200)
    t9.pendown()
    t9.pendown()
    t9.color("white")
    t9.write("Lives are: 1", font=("Arial", 14, "normal","bold"))
    t9.penup()
    t9.hideturtle()

  #print(villain["lives"])
  #print(villain["score"])  

screen = t.getscreen()#I tried to fix this, but it just destroyed me
screen.clear()
screen.setup(500,500)
screen.bgcolor("black")
screen.update()
t.tracer(0)
t9.penup()
t9.goto(100,100)
t9.pendown()
t9.color("black")
t9.write("Lives are: 1",font=("Arial", 14, "normal","bold"))
t9.penup()
t9.hideturtle()