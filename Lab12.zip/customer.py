import random
class Customer:
  def __init__(self,name, account_number):
    self.name=name
    self.account_number=account_number
    self.password=random.randint(100000,1000000)
  def get_account_display(self):
    return self.name.upper()+":" + str(self.account_number) + ":" + str(self.password)
    
