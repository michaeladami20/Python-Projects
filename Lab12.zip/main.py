######################################################
# Project: Lab 12
# UIN: 656717220
# URL to repl.it:https://repl.it/@madami5/lab-12-starter-1
######################################################
import customer
f = open('customers.txt')
lines=f.readlines()
f.close()
customer_list=[]
for i in range(len(lines)): 
  customer_list.append(customer.Customer(lines[i],i))
for ln in customer_list:
  print (ln.get_account_display())