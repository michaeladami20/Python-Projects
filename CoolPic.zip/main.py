#####################################################
# Project: Project 4
# Student Name:  Adami, Michael
# UIN: 656717220
# repl.it URL: https://repl.it/@madami5/ShamefulElderlyMultithreading
######################################################
import urllib.request,random

image_url3="https://steamcdn-a.akamaihd.net/steamcommunity/public/images/items/65980/0324c673d32f12eb02c84361b56b80d41b9c30a5.jpg"
image_url2 = "http://www.nasa.gov/sites/default/files/images/nasaLogo-570x450.png"
image_url = "https://toppng.com/public/uploads/preview/red-smoke-effect-png-11552156852hp219ollxh.png"
source_file = image_url.split('/')[-1]
source_file2 = image_url2.split('/')[-1]
source_file3 = image_url3.split('/')[-1]
source_file_ext = source_file.split('.')[-1]
source_file_ext2 = source_file2.split('.')[-1]
source_file_ext3 = source_file3.split('.')[-1]

urllib.request.urlretrieve(image_url,filename = source_file);
urllib.request.urlretrieve(image_url2,filename = source_file2);
urllib.request.urlretrieve(image_url3,filename = source_file3);

from PIL import Image,ImageDraw,ImageFont,ImageOps

smokey = Image.open(source_file)  #create an Image object by opening a file
nasa_logo=Image.open(source_file2)#create an Image object by opening a file 
background=Image.open(source_file3)#create an Image object by opening a file
background2=Image.new("RGBA",(1000,1000))#Question 1 1000x1000
 # the size attribute is a tuple

out=Image.new(background.mode,smokey.size)
width,height= nasa_logo.size

rotate_angle=[] #Question 8
rotate_angle.append(0)
rotate_angle.append(45)
rotate_angle.append(90)
rotate_angle.append(180)
rotate_angle.append(225)
rotate_angle.append(270)
rotate_angle.append(315)
print(rotate_angle)

for i in (rotate_angle):#Question 5
  new_logo=nasa_logo.rotate(random.choice(rotate_angle))#Question 4
for x in range(int(width/2)):#Question 7
    for y in range(int(height/2)):
        
        
        ##  number of values in tuple depends on mode

      r,g,b,a = nasa_logo.getpixel((x,y))
      mirror_y= height-y-1  
      mirror_x = width-x-1 
        # set the matching pixel
      if (width%2==0):
        nasa_logo.putpixel((x,y), (r,g,b,a))
        
      else:
        # determine the mirrored pixel and set        
         # -1 because lists are zero-indexed
        nasa_logo.putpixel((x,mirror_y), (r,random.randint(0,255),random.randint(0,255)))


smokey=smokey.resize((850,563))#Question 4
background=background.resize((1000,1000))
nasa_logo=nasa_logo.resize((570,450))  
new_logo=new_logo.resize((57,45))
width, height = nasa_logo.size 
#new_SLR=ImageOps.solarize(nasa_logo, threshold=128)
print(nasa_logo.mode)
nasa_GS=ImageOps.grayscale(nasa_logo)#Question 10
sizes={}#Question 9
sizes.update({'smokey': smokey.size, 'background':background.size, 'nasa_logo':nasa_logo.size})

print(sizes)
f = ImageFont.truetype("arial.ttf", 80)#Question 6
txt=ImageDraw.Draw(background2)

background2.paste(background,(0,0))
background2.paste(new_logo,(920,800),mask=new_logo)#Question 3 
background2.paste(smokey,(100,400),mask=smokey)
background2.paste(nasa_GS,(250,350),mask=nasa_logo)
background2.paste(smokey,(100,400),mask=smokey)
txt.text((920,100),"E",font=f,fill=(255,0,0))
txt.text((920,200),"X",font=f,fill=(255,0,0))
txt.text((920,300),"P",font=f,fill=(255,255,255))
txt.text((920,400),"L",font=f,fill=(255,255,255))
txt.text((920,500),"O",font=f,fill=(255,255,255))
txt.text((920,600),"R",font=f,fill=(0,0,255))
txt.text((920,700),"E",font=f,fill=(0,0,255))
background2.save("project4_656717220.png")#Question 2